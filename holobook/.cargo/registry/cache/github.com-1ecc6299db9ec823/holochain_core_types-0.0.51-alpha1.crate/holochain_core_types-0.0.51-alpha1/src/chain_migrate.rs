//! NOT YET AVAILABLE

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct ChainMigrate {}
